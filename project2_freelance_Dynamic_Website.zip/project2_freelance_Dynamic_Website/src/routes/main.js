const express=require("express")
const bodyParser=("body-parser")
const { route } = require('express/lib/application' ) 
const routes=express.Router()
const Detail=require("../models/Detail");
const async = require("hbs/lib/async");
const Slider=require("../models/Slider");
const Service=require("../models/Service");
const Contact=require("../models/Contact");

routes.get("/",async(req,res)=>{
     const details=await Detail.findOne({"_id":"6487fb6a35d99c3f922b52b5"});
     const slides=await Slider.find();
     const services=await Service.find()
     // console.log(slides);
     res.render("index",{
          details:details,
          slides:slides,
          services:services
     });
})

routes.get("/gallery",(req,res)=>{
       res.send("This is my Gallery Page");
})

//contact form
routes.post("/process-contact-form",async(req,res)=>{
            console.log(req.body);
            try{
                 const data=await Contact.create(req.body)
                 res.redirect("/");
            }catch(e){
                 console.log(e);
                 res.redirect("/");
            }

})
 
module.exports=routes;