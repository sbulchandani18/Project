// console.log("hello world");
const express=require("express")
const app=express()
const bodyParser=('body-parser')
const hbs=require("hbs");
const mongoose=require("mongoose");

const dotenv = require('dotenv');
const Detail=require("./models/Detail");
const Service=require("./models/Service");
const Slider=require("./models/Slider");

app.use(express.urlencoded({extended: true})); 

dotenv.config( { path : 'process.env'} )
const PORT = process.env.PORT || 5556

const routes=require('./routes/main');
const async = require("hbs/lib/async");
app.use('',routes);

app.use('/static',express.static("public"));

//template engine
app.set('view engine','hbs')
app.set("views","views");

// partials
hbs.registerPartials("views/partials");

// database connection
mongoose
  .connect(process.env.MONGO_PROD_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    // useCreateIndex: true,
  })
  .then(() => console.log("Database connected!"))
  .catch(err => console.log(err));

   //  Detail.create({
   //      brandName:"Info Technical Solution",
   //      brandIconUrl:"https://images.newindianexpress.com/uploads/user/imagelibrary/2023/3/4/w900X450/RCB.jpg?w=640&dpr=1.3",
   //      links : [
   //          {
   //             label:"Home",
   //             url: "/"
   //          },
   //          {
   //             label:"services",
   //             url: "/service"
   //          },
   //          {
   //             label:"Gallery",
   //             url: "/gallery"
   //          },
   //          {
   //             label:"About-Us",
   //             url: "/about"
   //          },
   //          {
   //             label:"Contact-Us",
   //             url: "/contact-us"
   //          },
            
   //      ],
   //  })

  //  Slider.create([
  //     {
  //        tittle:'this is my dynamic website',
  //        subTittle: 'Java is one of th most famous programming language',
  //        imgUrl:'/static/img/a.jpg',
  //          class:'active',
  //     },
  //     {
  //        tittle:'What is Django in Python',
  //        subTittle: 'Django is web framework of python programming',
  //        imgUrl:'/static/img/b.jpeg',
  //            class:'',
  //     },
  //     {
  //        tittle:'what about Express js',
  //        subTittle: 'Express is framework of node js',
  //        imgUrl:'/static/img/c.webp',
  //           class:'',
  //     }
  //  ])
 
//   Service.create([
//     {
//       tittle:'IIT BHU course',
//       description:'We provide course that helps our student in learning and in placements.',
//       linkText:'http://www.visitsachinwebsite.com',
//       link:'Check'
//   },
//     {
//       tittle:'Best Books for JEE',
//       description:'We provide course that helps our student in learning and in placements.',
//       linkText:'http://www.visitsachinwebsite.com',
//       link:'Check'
//   },
//     {
//       tittle:'Boost your prepration',
//       description:'We provide course that helps our student in learning and in placements.',
//       linkText:'http://www.visitsachinwebsite.com',
//       link:'Check'
//   }
// ])

app.listen(process.env.PORT|5556,()=>{
    console.log(`Server is running on http://localhost:5556`)
})