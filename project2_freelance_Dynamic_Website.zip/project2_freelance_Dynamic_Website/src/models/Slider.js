const mongoose=require("mongoose");

const Slider=mongoose.Schema({
    tittle: String, 
    subTittle: String,
    imgUrl: String,
    class:String
})

module.exports=mongoose.model('Slider',Slider);