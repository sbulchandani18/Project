const mongoose=require("mongoose");

const Service=mongoose.Schema({
    tittle: String,
    description: String,
    linkText: String,
    link: String
})
module.exports=mongoose.model('Service',Service);

